const arbuzeCheckbox = document.getElementById('arbuzeCheckbox');
const wantImage = document.getElementById('wantImage');
const dontWantImage = document.getElementById('dontWantImage');

arbuzeCheckbox.addEventListener('change', function () {
    if (arbuzeCheckbox.checked) {
        wantImage.style.display = 'block';
        dontWantImage.style.display = 'none';
    } else {
        wantImage.style.display = 'none';
        dontWantImage.style.display = 'block';
    }
});