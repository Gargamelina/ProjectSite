var rusik = [
    {
        name: " Жицкий Виталий Викторович",
        height: "185",
        Age: "24",
        gender: "Male"
    },
    {
        name: "Парий Богдан Сергеевич",
        height: "184",
        Age: "24",
        gender: "Male"
    },
    {
        name: "Вознюк Анна Сергеевна",
        height: "185",
        Age: "30",
        gender: "Female"
    }
];