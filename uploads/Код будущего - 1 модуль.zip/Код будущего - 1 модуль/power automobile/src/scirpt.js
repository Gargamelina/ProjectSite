let car ={
    model: "BMW",
    volume: 2600,
    power: 160
};

let key = true;

for (let key in car) {
    console.log(key + ":" + car[key]);
};

let dungeon = ["Michael", "Master", "450 bucks"];
