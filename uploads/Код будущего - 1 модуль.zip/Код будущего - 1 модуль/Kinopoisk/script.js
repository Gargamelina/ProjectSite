function toggleDescription(id) {
    var description = document.getElementById("description" + id);
    if (description.style.display === "none") {
      description.style.display = "block";
    } else {
      description.style.display = "none";
    }
  }