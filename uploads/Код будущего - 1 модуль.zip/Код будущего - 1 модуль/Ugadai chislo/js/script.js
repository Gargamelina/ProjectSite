document.getElementById('check').addEventListener('click', function() {
    var guess = document.getElementById('guess').value;
    var randomNumber = Math.floor(Math.random() * 20) + 1;
  
    if (isNaN(guess) || guess < 1 || guess > 20) {
      document.getElementsByClassName('message')[0].innerHTML = 'Введите число от 1 до 20';
    } else {
      if (guess == randomNumber) {
        document.getElementsByClassName('message')[0].innerHTML = 'Вы угадали!';
      } else {
        document.getElementsByClassName('message')[0].innerHTML = 'Вы не угадали. Попробуйте еще раз.';
      }
    }
  
    document.getElementById('guess').value = '';
  });