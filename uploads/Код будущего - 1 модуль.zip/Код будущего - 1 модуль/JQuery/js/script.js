$(document).ready(function() {
    $('#themeButton').click(function() {
       $('body').toggleClass('dark');
    });
 });