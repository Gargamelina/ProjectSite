function getSum(a, b) {
	return a + b;
}


function isPrime(number) {
	if (number <= 1) {
		return false;
	}

	for (var i = 2; i <= Math.sqrt(number); i++) {
		if (number % i === 0) {
			return false;
		}
	}

	return true;
}


var sum = getSum(3, 5);
console.log('Сумма: ' + sum);


var number = 17;
var isNumberPrime = isPrime(number);
console.log(number + ' является простым числом? ' + isNumberPrime);
