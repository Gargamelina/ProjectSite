class Emp(Person):
   
  def Print(self):
    print("Emp class called")
     
Emp_details = Emp("Salme", 65)
 

Emp_details.Display()
 

Emp_details.Print()