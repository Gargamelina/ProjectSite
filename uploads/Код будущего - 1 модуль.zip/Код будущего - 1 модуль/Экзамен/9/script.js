const coordinatesParagraph = document.getElementById('coordinates');

function handleMouseMove(event) {
	const x = event.pageX;
	const y = event.pageY;

	coordinatesParagraph.textContent = `Координаты: (${x}, ${y})`;
}

document.addEventListener('mousemove', handleMouseMove);
