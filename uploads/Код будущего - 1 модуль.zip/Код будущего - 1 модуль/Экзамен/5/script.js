for (var i = 1; i <= 10; i++) {
	console.log(i);
}
var number = 5;

for (var i = 1; i <= 10; i++) {
	var result = number * i;
	console.log(number + ' x ' + i + ' = ' + result);
}