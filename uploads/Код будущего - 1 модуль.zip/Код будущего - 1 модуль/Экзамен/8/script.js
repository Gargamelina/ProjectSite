function changeText() {
	var text = document.querySelector('.text');
	text.innerText = 'New Text';

	var color = text.style.color;
	if (color === 'black') {
		text.style.color = 'red';
	} else {
		text.style.color = 'black';
	}

	var li = document.createElement('li');
	li.innerText = 'New List Item';
	document.getElementById('list').appendChild(li);
}
