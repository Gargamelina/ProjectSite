var number = parseInt(prompt('Введите число:'));


if (number % 2 === 0) {
	console.log(number + ' - четное число.');
} else {
	console.log(number + ' - нечетное число.');
}
