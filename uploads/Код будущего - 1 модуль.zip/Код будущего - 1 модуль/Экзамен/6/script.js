var numbers = [1, 2, 3, 4, 5];

var sum = 0;
for (var i = 0; i < numbers.length; i++) {
	sum += numbers[i];
}

console.log('Сумма чисел: ' + sum);

var strings = ['hello', 'world', 'javascript'];

for (var i = 0; i < strings.length; i++) {
	var uppercaseString = strings[i].toUpperCase();
	console.log(uppercaseString);
}