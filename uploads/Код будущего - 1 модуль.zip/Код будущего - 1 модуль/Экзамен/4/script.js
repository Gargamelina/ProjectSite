var age = parseInt(prompt('Введите ваш возраст:'));


if (age >= 18) {
	console.log('Доступ разрешен');
} else {
	console.log('Доступ запрещен');
}
