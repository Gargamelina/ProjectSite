let number = 10;
let string = 'Привет Мир!';
let boolean = true;

console.log(number);
console.log(string);
console.log(boolean);