var num1 = parseFloat(prompt('Введите первое число:'));
var num2 = parseFloat(prompt('Введите второе число:'));


var sum = num1 + num2;


console.log('Сумма двух чисел равна: ' + sum);
