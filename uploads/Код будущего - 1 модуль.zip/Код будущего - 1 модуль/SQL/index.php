<?php
$fruits = array("яблоко", "банан", "апельсин");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SQL</title>
</head>
<body>
	<ul>
		<?php foreach ($fruits as $fruit): ?>
			<li><?php echo $fruit; ?></li>
		<?php endforeach; ?>
	</ul>	
	<?php echo "Hello_World1337" ?>
</body>
</html>