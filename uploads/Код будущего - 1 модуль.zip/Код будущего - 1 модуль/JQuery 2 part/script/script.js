const items = document.querySelectorAll ('.item');
items.forEach(item => {
    item.addEventListener('click',
    function() {
        items.forEach(element =>
            element.classList.remove('active'));

            this.classList.add('active');
    });
});
                    