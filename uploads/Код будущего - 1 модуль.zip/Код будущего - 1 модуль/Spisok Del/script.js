const todoInput = document.getElementById('todo-input');
const addBtn = document.getElementById('add-btn');
const list = document.getElementById('list');
const modal = document.getElementById('modal');
const confirmBtn = document.getElementById('confirm-btn');
const cancelBtn = document.getElementById('cancel-btn');

let todos = [];

addBtn.addEventListener('click', () => {
    const todoText = todoInput.value;
    if (todoText) {
        todos.push(todoText);
        displayTodos();
        todoInput.value = '';
    }
});

function displayTodos() {
    list.innerHTML = '';
    todos.forEach((todo, index) => {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <span>${todo}</span>
            <button onclick="openModal(${index})">Удалить</button>
        `;
        list.appendChild(listItem);
    });
}

function openModal(index) {
    confirmBtn.onclick = () => {
        deleteTodo(index);
        closeModal();
    };
    cancelBtn.onclick = () => {
        closeModal();
    };
    modal.style.display = 'flex';
}

function closeModal() {
    modal.style.display = 'none';
}

function deleteTodo(index) {
    todos.splice(index, 1);
    displayTodos();
}

