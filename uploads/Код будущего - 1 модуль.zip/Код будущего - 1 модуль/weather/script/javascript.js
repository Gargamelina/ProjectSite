const apiKey = '58776514b96d16a9a92c30930d4e5a52';

const city = 'Simferopol';

fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`)
    .then(response => response.json())
    .then(data => {
        const weatherDiv = document.getElementById('weather');
        weatherDiv.innerHTML = `
            <h2>${data.name}</h2>
            <p>Температура: ${data.main.temp}°C</p>
            <p>Описание: ${data.weather[0].description}</p>
        `;
    })
    .catch(error => {
        console.error(error);
    })