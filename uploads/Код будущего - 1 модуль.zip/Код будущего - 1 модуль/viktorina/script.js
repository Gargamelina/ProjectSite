const questions = [
    {
        question: "Какой язык программирования вы изучаете?",
        options: ["JavaScript", "Python", "Java", "C++"],
        correctAnswer: "JavaScript"
    },
    {
        question: "Что такое HTML?",
        options: ["База данных", "Гипертекстовый язык разметки", "Язык программирования", "Графический редактор"],
        correctAnswer: "Гипертекстовый язык разметки"
    },
    {
        question: "Что такое CSS?",
        options: ["Система управления", "Язык программирования", "Каскадные таблицы стилей", "Фреймворк"],
        correctAnswer: "Каскадные таблицы стилей"
    }
];

let currentQuestionIndex = 0;
let score = 0;

const questionElement = document.getElementById('question');
const optionsContainer = document.getElementById('options');
const resultElement = document.getElementById('result');
const scoreElement = document.getElementById('score');
const scoreValueElement = document.getElementById('score-value');

function startGame() {
    currentQuestionIndex = 0;
    score = 0;
    resultElement.innerText = '';
    scoreElement.style.display = 'block';
    scoreValueElement.innerText = score;
    showQuestion();
}

function showQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.innerText = currentQuestion.question;
    optionsContainer.innerHTML = '';
    currentQuestion.options.forEach(option => {
        const button = document.createElement('button');
        button.innerText = option;
        button.classList.add('option');
        button.addEventListener('click', selectAnswer);
        optionsContainer.appendChild(button);
    });
}

function selectAnswer(e) {
    const selectedButton = e.target;
    const correct = selectedButton.innerText === questions[currentQuestionIndex].correctAnswer;
    if (correct) {
        score++;
        scoreValueElement.innerText = score;
        resultElement.innerText = 'Правильно!';
    } else {
        resultElement.innerText = 'Неправильно. Попробуйте еще раз.';
    }

    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        endGame();
    }
}

function endGame() {
    questionElement.innerText = 'Игра окончена!';
    optionsContainer.innerHTML = '';
    resultElement.innerText = `Вы набрали ${score} из ${questions.length} правильных ответов.`;
    scoreElement.style.display = 'none';
}

startGame();